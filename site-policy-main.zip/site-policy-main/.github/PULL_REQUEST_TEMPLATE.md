# Thank you for your interest in improving GitHub's site policies!
![new](https://img.shields.io/badge/-new!-yellow) Please follow this workflow to have your edits considered:
1. Open a pull request directly in the [GitHub Docs](https://github.com/github/docs) repo.
2. Open [an issue in this site-policy repo](https://github.com/github/site-policy/issues/new) describing your change and link it to your PR.
3. We will then consider your change and get back to you. Thank you!
